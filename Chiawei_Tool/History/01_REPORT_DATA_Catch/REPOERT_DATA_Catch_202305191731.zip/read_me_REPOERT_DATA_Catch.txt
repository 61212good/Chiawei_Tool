//----------------------------------------------------[C]--------------------------------------------------------------//
gcc REPOERT_DATA_Catch.c & a.exe Default .\READ_ONLY\testlog_default.txt
gcc REPOERT_DATA_Catch.c & a.exe Query .\READ_ONLY\testlog_query.txt
gcc REPOERT_DATA_Catch.c & a.exe Time_count .\READ_ONLY\testbootloader_Timecount.txt
gcc REPOERT_DATA_Catch.c & a.exe AutoRecovery .\READ_ONLY\testlog_autorecovery.txt

REPOERT_DATA_Catch.exe Default .\READ_ONLY\testlog_default.txt
REPOERT_DATA_Catch.exe Query .\READ_ONLY\testlog_query.txt
REPOERT_DATA_Catch.exe Time_count .\READ_ONLY\testbootloader_Timecount.txt
REPOERT_DATA_Catch.exe AutoRecovery .\READ_ONLY\testlog_autorecovery.txt