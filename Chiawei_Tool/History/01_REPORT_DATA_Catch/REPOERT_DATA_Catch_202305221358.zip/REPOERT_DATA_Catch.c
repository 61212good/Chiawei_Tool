#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <math.h>
#define Nlen 10000//讀檔案每一行最大容量
#define maxlen 241//每一行最大的資料數量
#define maxlen_2 10//每一行最大的資料數量
#define total_catchlen ((241*3)-1)+3//擷取的字元總數(包含Register+:)
#define total_catchlen_2 ((10*3)-1)+3//擷取的字元總數(包含Register+:)
/* substr [提取 `src` 中存在的字符]
* @param {char*} src 原始的文字
* @param {int} m 開始的位置
* @param {int} n n-1=結束位置
* */ 
char* substr(const char *src, int m, int n)
{
	// 獲取目標字符串的長度
	int len = n - m;
 
	// 為目標分配 (len + 1) 個字符(+1 用於額外的空字符)
	char *dest = (char*)malloc(sizeof(char) * (len + 1));
 
	// 從源字符串中提取第 m 個和第 n 個索引之間的字符
	// 並將它們複製到目標字符串中
	for (int i = m; i < n && (*(src + i) != '\0'); i++)
	{
		*dest = *(src + i);
		dest++;
	}
 
	// 以空值結束目標字符串
	*dest = '\0';
 
	// 返回目標字符串
	return dest - len;
}
/* str_replace [字串取代] 
* @param {char*} source 原始的文字 
* @param {char*} find 搜尋的文字   
* @param {char*} rep 替換的文字 
* */ 
char *str_replace(char *source, char *find,  char *rep){ 
	// 搜尋文字的長度 
	int find_L=strlen(find); 
	// 替換文字的長度 
	int rep_L=strlen(rep); 
	// 結果文字的長度 
	int length=strlen(source)+1; 
	// 定位偏移量 
	int gap=0; 
 
	// 建立結果文字，並複製文字 
	char *result = (char*)malloc(sizeof(char) * length); 
	strcpy(result, source);	 
 
	// 尚未被取代的字串 
	char *former=source; 
	// 搜尋文字出現的起始位址指標 
	char *location= strstr(former, find); 
 
	// 漸進搜尋欲替換的文字 
	while(location!=NULL){ 
		// 增加定位偏移量 
		gap+=(location - former); 
		// 將結束符號定在搜尋到的位址上 
		result[gap]='\0'; 
 
		// 計算新的長度 
		length+=(rep_L-find_L); 
		// 變更記憶體空間 
		result = (char*)realloc(result, length * sizeof(char)); 
		// 替換的文字串接在結果後面 
		strcat(result, rep); 
		// 更新定位偏移量 
		gap+=rep_L; 
 
		// 更新尚未被取代的字串的位址 
		former=location+find_L; 
		// 將尚未被取代的文字串接在結果後面 
		strcat(result, former); 
 
		// 搜尋文字出現的起始位址指標 
		location= strstr(former, find); 
	}
	return result; 
}
/* Linear16_to_DEC [Linear16 to DEC] 
* @param {char*} hex_val 要轉換的HexData
* */ 
char *Linear16_to_DEC(char *hex_val){ 
	char *result = malloc (sizeof (char) * 20);

	int hex_val_int = 0;
	int Linear16_N = -9;
	int Linear16_Y = 0;
	double Linear16_X = 0;

	char strcat_dest_Linear[20];//字串合併
	memset(strcat_dest_Linear, 0, sizeof(strcat_dest_Linear));//初始化字串
	strcat(strcat_dest_Linear, "0X");//字串合併
	strcat(strcat_dest_Linear, hex_val);//字串合併

	hex_val_int = strtoul(strcat_dest_Linear, NULL, 0);

	Linear16_Y = hex_val_int;
	Linear16_X = Linear16_Y * pow(2,Linear16_N);
	sprintf(result,"%lf",Linear16_X);
	return result;
}
/* Linear11_to_DEC [Linear11 to DEC] 
* @param {char*} hex_val 要轉換的HexData
* */ 
char *Linear11_to_DEC(char *hex_val){ 
	char *result = malloc (sizeof (char) * 20);

	int hex_val_int = 0;
	int Linear11_N = 0;
	int Linear11_Y = 0;
	double Linear11_X = 0;

	char strcat_dest_Linear[20];//字串合併
	memset(strcat_dest_Linear, 0, sizeof(strcat_dest_Linear));//初始化字串
	strcat(strcat_dest_Linear, "0X");//字串合併
	strcat(strcat_dest_Linear, hex_val);//字串合併

	hex_val_int = strtoul(strcat_dest_Linear, NULL, 0);

	Linear11_N = hex_val_int >> 11;
	Linear11_Y = hex_val_int & 2047;//0000011111111111
	if(Linear11_N>=16){
		Linear11_N = 0 - ((~Linear11_N & 31) + 1);//00000000000000000000000000011111
	}
	Linear11_X = Linear11_Y * pow(2,Linear11_N);
	sprintf(result,"%lf",Linear11_X);
	return result;
}

int main(int argc, char *argv[]){
	//printf("argc_enter: %d\n",argc);//參數數量
	char* input_case;
	for(int i=0;i<argc;i++){
		//printf("argv_%d_enter: %s\n",i,argv[i]);//參數字串
		if(i==1){//模式參數
			input_case = argv[1];//輸入參數
		}else if(i==2){//文件地址參數
			char* input_filename = argv[2];//輸入字串
			char* output_filename_Default_ReadValue_0 = str_replace(input_filename,".txt","_Default_ReadValue.txt");//輸出Default_ReadValue檔名
			char* output_filename_Default_ReadValue = str_replace(output_filename_Default_ReadValue_0,"READ_ONLY","OUTPUT");//輸出Default_ReadValue檔名
			char* output_filename_Default_7Eh_0 = str_replace(input_filename,".txt","_Default_7Eh.txt");//輸出Default_7Eh檔名
			char* output_filename_Default_7Eh = str_replace(output_filename_Default_7Eh_0,"READ_ONLY","OUTPUT");//輸出Default_7Eh檔名
			char* output_filename_Query_ReadValue_0 = str_replace(input_filename,".txt","_Query_ReadValue.txt");//輸出Query_ReadValue檔名
			char* output_filename_Query_ReadValue = str_replace(output_filename_Query_ReadValue_0,"READ_ONLY","OUTPUT");//輸出Query_ReadValue檔名
			char* output_filename_Time_count_0 = str_replace(input_filename,".txt","_Timecount_after.txt");//輸出Time_count檔名
			char* output_filename_Time_count = str_replace(output_filename_Time_count_0,"READ_ONLY","OUTPUT");//輸出Time_count檔名
			char* output_filename_AutoRecovery_0 = str_replace(input_filename,".txt","_AutoRecovery_ReadValue.txt");//輸出_AutoRecovery檔名
			char* output_filename_AutoRecovery = str_replace(output_filename_AutoRecovery_0,"READ_ONLY","OUTPUT");//輸出_AutoRecovery檔名

			FILE *fptr_read = fopen(input_filename,"r");

			if(strncmp("Default", input_case, 7) == 0){//判斷輸入參數Default=========================================================
				if(fptr_read == NULL){//判斷文件是否打開失敗
					puts("Fail to open file!");
					exit(0);
				}else{
					char readstr[Nlen + 1];
					int fgets_count = 0;
					FILE *fptr_write_default_readvalue = fopen(output_filename_Default_ReadValue,"w");
					FILE *fptr_write_default_7eh = fopen(output_filename_Default_7Eh,"w");
					while(fgets(readstr, Nlen, fptr_read) != NULL){//讀取每一行
						if(fgets_count!=0){//第一行不讀
							if((fgets_count%3)==1){//第一行Default_log--------------------------------------------------------------
								const char* split = "：";
								char *after_split = strtok(readstr, split);
								int strtok_count = 0;
								while (after_split != NULL) {//讀取每一行的切割後
									if(strtok_count==1){//讀取切割後第二個字串
										char* after_replace_0 = str_replace(after_split," S 58 W ","");//取代
										char* after_replace_1 = str_replace(after_replace_0," Sr 58  R ",":");//取代
										char* after_replace = str_replace(after_replace_1," ","-");//取代

										char* Deafault_rowdata = substr(after_replace,3,total_catchlen);//after_substr一行的DEFAULT資料
										char* Deafault_rowdata_tmp = substr(after_replace,3,total_catchlen);//after_substr一行的DEFAULT資料

										const char* Deafault_row_split = "-";
										char *after_Deafault_row_split = strtok(Deafault_rowdata, Deafault_row_split);
										int Deafault_row_split_count = 0;
										char *last_data = "";
										int nowdata_address = 0;
										int savedata_count = 0;

										while (after_Deafault_row_split != NULL) {//讀取一行的DEFAULT資料切割後
											if(strncmp("FF", after_Deafault_row_split, 2) == 0 && 
												nowdata_address != 0 && 
												strncmp("FF", last_data, 2) != 0){//當前資料為FF，且不是第一個資料，且上一個資料不是FF
												savedata_count = nowdata_address - 1;//擷取的資料數量
											}
											last_data = after_Deafault_row_split;
											nowdata_address++;

											after_Deafault_row_split = strtok(NULL, Deafault_row_split);
											Deafault_row_split_count++;
										}

										if(savedata_count == 0 || strncmp("FF", last_data, 2) != 0){//若全為FF或最後一個資料不是FF
											savedata_count = maxlen;//擷取的資料數量
										}

										int savedata_address = (savedata_count * 3) - 1;//擷取的字元總數

										Deafault_rowdata = substr(Deafault_rowdata_tmp,0,savedata_address);//after_substr一行的DEFAULT資料

										char strcat_dest[1000];//字串合併
										memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串
										strcat(strcat_dest, Deafault_rowdata);//字串合併
										strcat(strcat_dest, "h\n");//字串合併

										fprintf(fptr_write_default_readvalue,"%s",strcat_dest);
									}
									after_split = strtok(NULL, split);
									strtok_count++;
								}
							}else if((fgets_count%3)==2){//第二行7Eh_log--------------------------------------------------------------
								const char* split = "：";
								char *after_split = strtok(readstr, split);
								int strtok_count = 0;
								while (after_split != NULL) {//讀取每一行的切割後
									if(strtok_count==1){//讀取切割後第二個字串
										char* after_replace_0 = str_replace(after_split," S 58 W 06 02 00 7E Sr 58  R 01 ","");//取代
										char* after_replace_1 = str_replace(after_replace_0," S 58 W 06 02 01 7E Sr 58  R 01 ","");//取代

										char* after_substr = substr(after_replace_1,0,3);//after_substr

										char* after_replace = str_replace(after_substr," ","h\n");//取代

										fprintf(fptr_write_default_7eh,"%s",after_replace);
									}
									after_split = strtok(NULL, split);
									strtok_count++;
								}
							}else if((fgets_count%3)==3){//第三行clearfault
								
							}
						}
						fgets_count++;
					}
					fclose(fptr_write_default_readvalue);
					fclose(fptr_write_default_7eh);

					printf("%s\n", output_filename_Default_ReadValue);
					printf("%s\n", output_filename_Default_7Eh);
				}

				fclose(fptr_read);
			}else if(strncmp("Query", input_case, 5) == 0){//判斷輸入參數Query=========================================================
				if(fptr_read == NULL){//判斷文件是否打開失敗
					puts("Fail to open file!");
					exit(0);
				}else{
					char readstr[Nlen + 1];
					int fgets_count = 0;
					FILE *fptr_write_query_readvalue = fopen(output_filename_Query_ReadValue,"w");
					while(fgets(readstr, Nlen, fptr_read) != NULL){//讀取每一行
						const char* split = "：";
						char *after_split = strtok(readstr, split);
						int strtok_count = 0;
						while (after_split != NULL) {//讀取每一行的切割後
							if(strtok_count==1){//讀取切割後第二個字串
								char strcat_dest[1000];//字串合併
								memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串

								char* after_replace_0 = str_replace(after_split," S 58 W 1A 01 ","");//取代
								char* after_replace_1 = str_replace(after_replace_0," Sr 58  R ",":");//取代
								char* after_replace_2 = str_replace(after_replace_1," ","-");//取代

								char* after_substr = substr(after_replace_2,3,8);//after_substr

								strcat(strcat_dest, after_substr);//字串合併
								strcat(strcat_dest, "h\n");//字串合併

								fprintf(fptr_write_query_readvalue,"%s",strcat_dest);
							}
							after_split = strtok(NULL, split);
							strtok_count++;
						}
						fgets_count++;
					}
					fclose(fptr_write_query_readvalue);

					printf("%s\n", output_filename_Query_ReadValue);
				}

				fclose(fptr_read);
			}else if(strncmp("Time_count", input_case, 10) == 0){//判斷輸入參數Time_count=========================================================
				if(fptr_read == NULL){//判斷文件是否打開失敗
					puts("Fail to open file!");
					exit(0);
				}else{
					char readstr[Nlen + 1];
					int fgets_count = 0;
					FILE *fptr_write_Time = fopen(output_filename_Time_count,"w");
					while(fgets(readstr, Nlen, fptr_read) != NULL){//讀取每一行
						char* after_substr = substr(readstr,1,11);//after_substr
						if(strncmp("2023-05-15", after_substr, 10) == 0){
							char* cahr_time = substr(readstr,13,28);//after_substr
							const char* split = ":";
							char *after_split = strtok(cahr_time, split);
							int strtok_count = 0;
							double adddata = 64067.634;//要加上的時間
							double totaltime = 0;
							int readhour = 0;
							int readmin = 0;
							int readsec = 0;
							double  readsecmin = 0;
							int totaltime_int = 0;
							while (after_split != NULL) {//讀取每一行時間的切割後
								if(strtok_count==0){//讀取切割後第1個字串
									readhour = strtoul(after_split, NULL, 0);
								}
								if(strtok_count==1){//讀取切割後第2個字串
									readmin = strtoul(after_split, NULL, 0);
								}
								if(strtok_count==2){//讀取切割後第3個字串
									readsec = strtoul(after_split, NULL, 0);
								}
								if(strtok_count==3){//讀取切割後第4個字串
									readsecmin = strtoul(after_split, NULL, 0);
								}
								totaltime = (readhour * 60 * 60) + (readmin * 60) + (readsec) + (readsecmin/1000000);
								after_split = strtok(NULL, split);
								strtok_count++;
							}
							totaltime = adddata + totaltime;//更新time
							totaltime_int = totaltime;
							if(totaltime_int>=(24*3600)){
								totaltime = totaltime - (24*3600);
								totaltime_int = totaltime_int - (24*3600);
							}
							int afterhour = (totaltime_int/3600);
							int aftermin = ((totaltime_int-afterhour*3600)/60);
							int aftersec = ((totaltime_int-afterhour*3600-aftermin*60));
							double aftersecmin = totaltime - totaltime_int;
							int aftersecmin_int = (aftersecmin*1000000);

							char afterhour_str[20];
							sprintf(afterhour_str,"%d",afterhour);
							char aftermin_str[20];
							sprintf(aftermin_str,"%d",aftermin);
							char aftersec_str[20];
							sprintf(aftersec_str,"%d",aftersec);
							char aftersecmin_str[20];
							sprintf(aftersecmin_str,"%d",aftersecmin_int);
							if(strlen(afterhour_str)==1){
								char strcat_dest[20];//字串合併
								memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串
								strcat(strcat_dest, "0");//字串合併
								strcat(strcat_dest, afterhour_str);//字串合併
								strcpy(afterhour_str,strcat_dest);
							}
							if(strlen(aftermin_str)==1){
								char strcat_dest[20];//字串合併
								memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串
								strcat(strcat_dest, "0");//字串合併
								strcat(strcat_dest, aftermin_str);//字串合併
								strcpy(aftermin_str,strcat_dest);
							}
							if(strlen(aftersec_str)==1){
								char strcat_dest[20];//字串合併
								memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串
								strcat(strcat_dest, "0");//字串合併
								strcat(strcat_dest, aftersec_str);//字串合併
								strcpy(aftersec_str,strcat_dest);
							}
							if(strlen(aftersecmin_str)<6){
								char strcat_dest[20];//字串合併
								memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串
								int add_count = 6 - strlen(aftersecmin_str);
								for(int i=1;i<=add_count;i++){
									strcat(strcat_dest, "0");//字串合併
								}
								strcat(strcat_dest, aftersecmin_str);//字串合併
								strcpy(aftersecmin_str,strcat_dest);
							}

							char* ouput_part1 = substr(readstr,0,13);//after_substr
							char* ouput_part3 = substr(readstr,28,(strlen(readstr)-1));//after_substr
							
							fprintf(fptr_write_Time,"%s",ouput_part1);
							fprintf(fptr_write_Time,"%s:%s:%s:%s",afterhour_str,aftermin_str,aftersec_str,aftersecmin_str);
							fprintf(fptr_write_Time,"%s\n",ouput_part3);
						}else{
							fprintf(fptr_write_Time,"%s",readstr);
						}
						fgets_count++;
					}
					fclose(fptr_write_Time);

					printf("%s\n", output_filename_Time_count);
				}

				fclose(fptr_read);
			}else if(strncmp("AutoRecovery", input_case, 12) == 0){//判斷輸入參數AutoRecovery=========================================================
				/*for(int i=1;i<=66;i++){
					int testa = 0;
					testa = i % 22;
					printf("%d\%%22 = %d\n", i,testa);
				}*/
				if(fptr_read == NULL){//判斷文件是否打開失敗
					puts("Fail to open file!");
					exit(0);
				}else{
					char readstr[Nlen + 1];
					int fgets_count = 1;
					FILE *fptr_write_autorecovery = fopen(output_filename_AutoRecovery,"w");
					while(fgets(readstr, Nlen, fptr_read) != NULL){//讀取每一行
						if((fgets_count%22)!=1){//第一行WritePage不讀,只讀後面的

							const char* split = "：";
							char *after_split = strtok(readstr, split);
							int strtok_count = 0;

							while (after_split != NULL) {//讀取每一行的切割後
								if(strtok_count==1){//讀取切割後第二個字串
									char* after_replace_0 = str_replace(after_split," S 58 W ","");//取代
									char* after_replace_1 = str_replace(after_replace_0," Sr 58  R ",":");//取代
									char* after_replace = str_replace(after_replace_1," ","-");//取代

									char* AutoRecovery_rowdata = substr(after_replace,3,total_catchlen_2);//after_substr一行的DEFAULT資料
									char* AutoRecovery_rowdata_tmp = substr(after_replace,3,total_catchlen_2);//after_substr一行的DEFAULT資料

									const char* Deafault_row_split = "-";
									char *after_Deafault_row_split = strtok(AutoRecovery_rowdata, Deafault_row_split);
									int Deafault_row_split_count = 0;
									char *last_data = "";
									int nowdata_address = 0;
									int savedata_count = 0;

									while (after_Deafault_row_split != NULL) {//讀取一行的DEFAULT資料切割後
										if(strncmp(last_data, after_Deafault_row_split, 2) == 0 &&
											savedata_count == 0){//當前資料等於上一個資料且擷取的資料數量尚未被寫入
											savedata_count = nowdata_address - 1;//擷取的資料數量
										}else if(strncmp(last_data, after_Deafault_row_split, 2) != 0){//當前資料不等於上一個資料
											savedata_count = 0;
										}
										//if(strncmp("FF", after_Deafault_row_split, 2) == 0 && 
										//	nowdata_address != 0 && 
										//	strncmp("FF", last_data, 2) != 0){//當前資料為FF，且不是第一個資料，且上一個資料不是FF
										//	savedata_count = nowdata_address - 1;//擷取的資料數量
										//}
										last_data = after_Deafault_row_split;
										nowdata_address++;

										after_Deafault_row_split = strtok(NULL, Deafault_row_split);
										Deafault_row_split_count++;
									}

									if(savedata_count == 0){//若都不符合PEC條件
										savedata_count = maxlen_2;//擷取的資料數量
									}
									/*if(savedata_count == 0 || strncmp("FF", last_data, 2) != 0){//若全為FF或最後一個資料不是FF
										savedata_count = maxlen_2;//擷取的資料數量
									}*/

									int savedata_address = (savedata_count * 3) - 1;//擷取的字元總數

									AutoRecovery_rowdata = substr(AutoRecovery_rowdata_tmp,0,savedata_address);//after_substr一行的DEFAULT資料

									char strcat_dest[1000];//字串合併
									memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串
									strcat(strcat_dest, AutoRecovery_rowdata);//字串合併
									strcat(strcat_dest, "h");//字串合併

									if((fgets_count%22) > 12 || (fgets_count%22) == 0){//第12行以後計算Linear11
										strcat(strcat_dest, "	");//字串合併

										const char* split_Linear = "-";
										char *after_split_Linear = strtok(AutoRecovery_rowdata, split_Linear);
										int strtok_count_Linear = 0;

										char* LowByte_read = "";
										char* HighByte_read = "";
										char* Hex_to_Dec_str = "";
										while (after_split_Linear != NULL) {//讀取每一行的切割後

											if(strtok_count_Linear==0){//LowByte
												LowByte_read = after_split_Linear;
											}else if(strtok_count_Linear==1){//HighByte
												HighByte_read = after_split_Linear;
											}

											after_split_Linear = strtok(NULL, split_Linear);
											strtok_count_Linear++;
										}

										char Hex_read[1000];//字串合併
										memset(Hex_read, 0, sizeof(Hex_read));//初始化字串
										strcat(Hex_read, HighByte_read);//字串合併
										strcat(Hex_read, LowByte_read);//字串合併

										if((fgets_count%22) == 15){//第15行計算Linear16
											Hex_to_Dec_str = Linear16_to_DEC(Hex_read);//Linear16_to_DEC
										}else{//計算Linear11
											Hex_to_Dec_str = Linear11_to_DEC(Hex_read);//Linear11_to_DEC
										}

										strcat(strcat_dest, Hex_to_Dec_str);//字串合併
										strcat(strcat_dest, "\n");//字串合併
									}else{
										strcat(strcat_dest, "	");//字串合併
										strcat(strcat_dest, AutoRecovery_rowdata);//字串合併
										strcat(strcat_dest, "h\n");//字串合併
									}

									fprintf(fptr_write_autorecovery,"%s",strcat_dest);
								}
								after_split = strtok(NULL, split);
								strtok_count++;
							}
						}else{//第一行WritePage
							fprintf(fptr_write_autorecovery,"\n");
						}
						fgets_count++;
					}
					fclose(fptr_write_autorecovery);

					printf("%s\n", output_filename_AutoRecovery);
				}

				fclose(fptr_read);
			}else if(strncmp("test", input_case, 4) == 0){//判斷輸入參數test=========================================================
				char* test = "1B00";
				printf("test_mode:%s\n",Linear16_to_DEC(test));
				char* test2 = "F076";
				printf("test_mode:%s\n",Linear11_to_DEC(test2));
				fclose(fptr_read);				
			}else{
				puts("Fail to switch_case!");
				exit(0);
			}
		}
	}
	return 0;
}