#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "dirent.h"
#include <math.h>

#define READ_ONLY_Path "./READ_ONLY/"						//READ_ONLY PATH
#define OUTPUT_LIST_Path "./READ_ONLY/output_list/"						//READ_ONLY PATH

typedef volatile unsigned char		UINT8;					// Volatele UINT8
typedef const unsigned char			C_UINT8;				// Constant UINT8
UINT8 ubPmbusPec = 0x00;									// Q0, PMBus PEC

//----- CRC8 -----
C_UINT8 ubaHiCrc[16] = {
	0x00, 0x70, 0xE0, 0x90, 0xC7, 0xB7, 0x27, 0x57,
	0x89, 0xF9, 0x69, 0x19, 0x4E, 0x3E, 0xAE, 0xDE};		// Q0, HiCrc
C_UINT8 ubaLoCrc[16] = {
	0x00, 0x07, 0x0E, 0x09, 0x1C, 0x1B, 0x12, 0x15,
	0x38, 0x3F, 0x36, 0x31, 0x24, 0x23, 0x2A, 0x2D};		// Q0, LoCrc

/* CalPec [計算PEC] 
* @param {UINT8} ubData 要計算PEC的Hex
* */ 
void CalPec(UINT8 ubData) {
	/********************************************************/
	/*				________								*/
	/*				|		|								*/
	/*	ubData	--->|		|--->	ubPmbusPec				*/
	/*				|_______|								*/
	/*														*/
	/*	Description:										*/
	/*	Calculation PEC (CRC-8) for communication			*/
	/*														*/
	/********************************************************/
//-- C
	UINT8 iubHiByte;										// Q0, High byte
	UINT8 iubLoByte;										// Q0, Low byte

	ubPmbusPec ^= ubData;									// Q0, ubPmbusPec
	iubHiByte = (ubPmbusPec >> 4) & 0x0F;					// Q0, iubHiByte
	iubLoByte = ubPmbusPec & 0x0F;							// Q0, iubLoByte
	ubPmbusPec = ubaHiCrc[iubHiByte];						// Q0, ubPmbusPec
	ubPmbusPec ^= ubaLoCrc[iubLoByte];						// Q0, ubPmbusPec
}
/* Hexstr_to_int [HexStr to int] 
* @param {char*} hex_val 要轉換的HexData
* */ 
int HexStr_to_int(char *hex_val){
	int result = 0;
	char HexStr[100];//字串合併
	memset(HexStr, 0, sizeof(HexStr));//初始化字串
	strcat(HexStr, "0X");//字串合併
	strcat(HexStr, hex_val);//字串合併
	result = strtoul(HexStr, NULL, 0);

	return result;
}
/* Linear16_to_DEC [Linear16 to DEC] 
* @param {char*} hex_val 要轉換的HexData
* */ 
char *Linear16_to_DEC(char *hex_val){ 
	char *result = malloc (sizeof (char) * 20);

	int hex_val_int = 0;
	int Linear16_N = -9;
	int Linear16_Y = 0;
	double Linear16_X = 0;

	hex_val_int = HexStr_to_int(hex_val);

	Linear16_Y = hex_val_int;
	Linear16_X = Linear16_Y * pow(2,Linear16_N);
	sprintf(result,"%lf",Linear16_X);

	return result;
}
/* Linear11_to_DEC [Linear11 to DEC] 
* @param {char*} hex_val 要轉換的HexData
* */ 
char *Linear11_to_DEC(char *hex_val){ 
	char *result = malloc (sizeof (char) * 20);

	int hex_val_int = 0;
	int Linear11_N = 0;
	int Linear11_Y = 0;
	double Linear11_X = 0;

	hex_val_int = HexStr_to_int(hex_val);

	Linear11_N = hex_val_int >> 11;
	Linear11_Y = hex_val_int & 2047;//0000011111111111
	if(Linear11_N>=16){//10000
		Linear11_N = 0 - ((~Linear11_N & 31) + 1);//00000000000000000000000000011111
	}
	if(Linear11_Y>=1024){//0000010000000000
		Linear11_Y = 0 - ((~Linear11_Y & 2047) + 1);//00000000000000000000011111111111
	}
	Linear11_X = Linear11_Y * pow(2,Linear11_N);
	sprintf(result,"%lf",Linear11_X);

	return result;
}
/* Direct_to_DEC [Direct to DEC] 
* @param {char*} read_data_last I2C讀到的Data(上一筆資料)(不含開頭0x06)
* @param {char*} read_data_current I2C讀到的Data(新的一筆資料)(不含開頭0x06)
* Example->
* 88-70-01-45-01-00(上一筆資料)
* 1A-7E-01-57-01-00(新的一筆資料)
* ->193
* 53-65-0B-4E-0C-00(上一筆資料)
* 1F-39-0C-FB-0C-00(新的一筆資料)
* ->123
* */
char *Direct_to_DEC(char *read_data_last, char *read_data_current){
	char *read_data_last_clear = malloc (sizeof (char) * 20);//初始化收到的變數
	sprintf(read_data_last_clear,"%s",read_data_last);
	char *read_data_current_clear = malloc (sizeof (char) * 20);//初始化收到的變數
	sprintf(read_data_current_clear,"%s",read_data_current);
	char *result = malloc (sizeof (char) * 20);

	int Maximum_Direct_Format_Value = 32767;
	double Average_Power = 0;

	int last_ACCUMULATOR_LOW = 0;
	int last_ACCUMULATOR_HIGH = 0;
	int last_ACCUMULATOR = 0;
	int last_ROLLOVER_COUNT = 0;
	int last_SAMPLE_COUNT_HIGH = 0;
	int last_SAMPLE_COUNT_MID = 0;
	int last_SAMPLE_COUNT_LOW = 0;
	int last_SAMPLE_COUNT = 0;
	int last_ENERGY_COUNT = 0;

	int current_ACCUMULATOR_LOW = 0;
	int current_ACCUMULATOR_HIGH = 0;
	int current_ACCUMULATOR = 0;
	int current_ROLLOVER_COUNT = 0;
	int current_SAMPLE_COUNT_HIGH = 0;
	int current_SAMPLE_COUNT_MID = 0;
	int current_SAMPLE_COUNT_LOW = 0;
	int current_SAMPLE_COUNT = 0;
	int current_ENERGY_COUNT = 0;

	const char* split_Direct_last = "-";
	char *after_split_Direct_last = strtok(read_data_last_clear, split_Direct_last);
	int strtok_count_Direct_last = 0;
	while (after_split_Direct_last != NULL) {//讀取每一行的切割後
		if(strtok_count_Direct_last==0){//ACCUMULATOR_LOW
			last_ACCUMULATOR_LOW = HexStr_to_int(after_split_Direct_last);
		}else if(strtok_count_Direct_last==1){//ACCUMULATOR_HIGH
			last_ACCUMULATOR_HIGH = HexStr_to_int(after_split_Direct_last);
			last_ACCUMULATOR_HIGH = last_ACCUMULATOR_HIGH << 8;
			current_ACCUMULATOR = last_ACCUMULATOR_HIGH | last_ACCUMULATOR_LOW;
		}else if(strtok_count_Direct_last==2){//ROLLOVER_COUNT
			last_ROLLOVER_COUNT = HexStr_to_int(after_split_Direct_last);
			last_ENERGY_COUNT = (last_ROLLOVER_COUNT * Maximum_Direct_Format_Value) + current_ACCUMULATOR;
		}else if(strtok_count_Direct_last==3){//SAMPLE_COUNT_LOW
			last_SAMPLE_COUNT_LOW = HexStr_to_int(after_split_Direct_last);
		}else if(strtok_count_Direct_last==4){//SAMPLE_COUNT_MID
			last_SAMPLE_COUNT_MID = HexStr_to_int(after_split_Direct_last);
			last_SAMPLE_COUNT_MID = last_SAMPLE_COUNT_MID << 8;
		}else if(strtok_count_Direct_last==5){//SAMPLE_COUNT_HIGH
			last_SAMPLE_COUNT_HIGH = HexStr_to_int(after_split_Direct_last);
			last_SAMPLE_COUNT_HIGH = last_SAMPLE_COUNT_HIGH << 16;
			last_SAMPLE_COUNT = last_SAMPLE_COUNT_HIGH | last_SAMPLE_COUNT_MID | last_SAMPLE_COUNT_LOW;
		}
		after_split_Direct_last = strtok(NULL, split_Direct_last);
		strtok_count_Direct_last++;
	}

	const char* split_Direct_current = "-";
	char *after_split_Direct_current = strtok(read_data_current_clear, split_Direct_current);
	int strtok_count_Direct_current = 0;
	while (after_split_Direct_current != NULL) {//讀取每一行的切割後
		if(strtok_count_Direct_current==0){//ACCUMULATOR_LOW
			current_ACCUMULATOR_LOW = HexStr_to_int(after_split_Direct_current);
		}else if(strtok_count_Direct_current==1){//ACCUMULATOR_HIGH
			current_ACCUMULATOR_HIGH = HexStr_to_int(after_split_Direct_current);
			current_ACCUMULATOR_HIGH = current_ACCUMULATOR_HIGH << 8;
			current_ACCUMULATOR = current_ACCUMULATOR_HIGH | current_ACCUMULATOR_LOW;
		}else if(strtok_count_Direct_current==2){//ROLLOVER_COUNT
			current_ROLLOVER_COUNT = HexStr_to_int(after_split_Direct_current);
			current_ENERGY_COUNT = (current_ROLLOVER_COUNT * Maximum_Direct_Format_Value) + current_ACCUMULATOR;
		}else if(strtok_count_Direct_current==3){//SAMPLE_COUNT_LOW
			current_SAMPLE_COUNT_LOW = HexStr_to_int(after_split_Direct_current);
		}else if(strtok_count_Direct_current==4){//SAMPLE_COUNT_MID
			current_SAMPLE_COUNT_MID = HexStr_to_int(after_split_Direct_current);
			current_SAMPLE_COUNT_MID = current_SAMPLE_COUNT_MID << 8;
		}else if(strtok_count_Direct_current==5){//SAMPLE_COUNT_HIGH
			current_SAMPLE_COUNT_HIGH = HexStr_to_int(after_split_Direct_current);
			current_SAMPLE_COUNT_HIGH = current_SAMPLE_COUNT_HIGH << 16;
			current_SAMPLE_COUNT = current_SAMPLE_COUNT_HIGH | current_SAMPLE_COUNT_MID | current_SAMPLE_COUNT_LOW;
		}

		after_split_Direct_current = strtok(NULL, split_Direct_current);
		strtok_count_Direct_current++;
	}

	Average_Power = (current_ENERGY_COUNT - last_ENERGY_COUNT) / (current_SAMPLE_COUNT - last_SAMPLE_COUNT);
	sprintf(result,"%lf",Average_Power);

	return result;
}

int main(){
	while(1){
		printf("//------------------------------------------------//\n");
		printf("//function List:\n");
		printf("//( 1 ) PEC\n");
		printf("//( 2 ) DIR_READONLY\n");
		printf("//( 3 ) REPORT_DATA_Catch output_list\n");
		printf("//( 4 ) Linear11 to Dec\n");
		printf("//( 5 ) Linear16 to Dec\n");
		printf("//( 6 ) Direct to Dec\n");
		printf("//------------------------------------------------//\n\n");

		int select_num = 0;

		printf("[FUNCTION.exe]: select function num:");
		scanf("%d",&select_num);

		if(select_num==1){//function PEC========================================================================================
			char PEC_cmd_str[1000];

			while(1){
				printf("[FUNCTION.exe_PEC]: input I2C cmd:");
				scanf("%s",&PEC_cmd_str);
				if(strncmp("exit", PEC_cmd_str, 4) == 0){
					break;
				}else{
					const char* split_inputcmd = "-";
					char *after_split_inputcmd = strtok(PEC_cmd_str, split_inputcmd);
					int strtok_count_inputcmd = 0;
					printf("\n");

					while (after_split_inputcmd != NULL) {//讀取每一行的切割後						
						UINT8 integer = HexStr_to_int(after_split_inputcmd);
						CalPec(integer);
						
						printf("string = 0X%s,int = %d\n",after_split_inputcmd,integer);

						after_split_inputcmd = strtok(NULL, split_inputcmd);
						strtok_count_inputcmd++;
					}
					printf("PEC = 0X%X\n\n",ubPmbusPec);
					ubPmbusPec = 0x00;
				}
			}
		}else if(select_num==2){//function DIR_READONLY========================================================================================

			DIR *dir = NULL;
			struct dirent *entry;

			if((dir = opendir(READ_ONLY_Path))==NULL){
				printf("[FUNCTION.exe_DIR_READONLY]: opendir failed!\n");
				system("pause");
			}else{				
				printf("[FUNCTION.exe_DIR_READONLY]: DIR\n");
				while(entry=readdir(dir)) {
					//printf("filename= %s\n",entry->d_name);  //輸出檔案或者目錄的名稱
					//printf("filetype = %d\n",entry->d_type);  //輸出檔案型別
					printf("%s\n",entry->d_name);  //輸出檔案或者目錄的名稱
				}
				closedir(dir);
				system("pause");
			}

		}else if(select_num==3){//function REPORT_DATA_Catch output_list========================================================================================
			char input_case[100];

			while(1){
				printf("[FUNCTION.exe_output_list]:========[Default]=============\n");
				printf("[FUNCTION.exe_output_list]:========[Query]===============\n");
				printf("[FUNCTION.exe_output_list]:========[Time_count]==========\n");
				printf("[FUNCTION.exe_output_list]:========[AutoRecovery]========\n");
				printf("[FUNCTION.exe_output_list]: input report case:");
				scanf("%s",&input_case);
				if(strncmp("exit", input_case, 4) == 0){
					break;
				}else{
					DIR *dir = NULL;
					struct dirent *entry;

					if((dir = opendir(OUTPUT_LIST_Path))==NULL){
						printf("[FUNCTION.exe_output_list]: opendir failed!\n");
					}else{
						while(entry=readdir(dir)) {
							if(entry->d_type == 0){	//文件型別	
								char system_cmd[200];//字串合併
								memset(system_cmd, 0, sizeof(system_cmd));//初始化字串
								strcat(system_cmd, "REPORT_DATA_Catch.exe ");//字串合併
								strcat(system_cmd, input_case);//字串合併
								strcat(system_cmd, " .\\READ_ONLY\\output_list\\");//字串合併
								strcat(system_cmd, entry->d_name);//字串合併
								system(system_cmd);
							}
						}
						closedir(dir);
					}
				}
			}
		}else if(select_num==4){//function Linear11 to Dec========================================================================================
			char Linear11_str[1000];

			while(1){
				printf("[FUNCTION.exe_Linear11]: input Linear11:");
				scanf("%s",&Linear11_str);
				if(strncmp("exit", Linear11_str, 4) == 0){
					break;
				}else{
					printf("\nDec = %s\n\n",Linear11_to_DEC(Linear11_str));
				}
			}
		}else if(select_num==5){//function Linear16 to Dec========================================================================================
			char Linear16_str[1000];

			while(1){
				printf("[FUNCTION.exe_Linear16]: input Linear16:");
				scanf("%s",&Linear16_str);
				if(strncmp("exit", Linear16_str, 4) == 0){
					break;
				}else{
					printf("\nDec = %s\n\n",Linear16_to_DEC(Linear16_str));
				}
			}
		}else if(select_num==6){//function Direct to Dec========================================================================================
			char Direct_str_1[1000];
			char Direct_str_2[1000];

			while(1){
				printf("[FUNCTION.exe_Direct]: input first Direct:");
				scanf("%s",&Direct_str_1);
				if(strncmp("exit", Direct_str_1, 4) == 0){
					break;
				}
				printf("[FUNCTION.exe_Direct]: input second Direct:");
				scanf("%s",&Direct_str_2);
				if(strncmp("exit", Direct_str_2, 4) == 0){
					break;
				}

				char *Direct_to_DEC_return = Direct_to_DEC(Direct_str_1,Direct_str_2);
				printf("\nfirst Direct = %s,\nsecond Direct = %s,\nDec = %s\n\n",Direct_str_1,Direct_str_2,Direct_to_DEC_return);
			}
		}else{
			printf("select function not found!\n");
			break;
		}
	}

	return 0;
}