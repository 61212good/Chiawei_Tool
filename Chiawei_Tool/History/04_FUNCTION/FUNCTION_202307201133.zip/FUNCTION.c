#include <stdio.h>
#include <string.h> 
#include <stdlib.h>
#include <math.h>
#include <dirent.h>
#include "./include/myfunction.h"

#define READ_ONLY_Path "./READ_ONLY/"						//READ_ONLY PATH
#define OUTPUT_LIST_Path "./READ_ONLY/output_list/"			//READ_ONLY OUTPUT LIST PATH

int main(){
	while(1){
		printf("//------------------------------------------------//\n");
		printf("//function List:\n");
		printf("//( 1 ) PEC\n");
		printf("//( 2 ) DIR_READONLY\n");
		printf("//( 3 ) REPORT_DATA_Catch output_list\n");
		printf("//( 4 ) Linear11 to Dec\n");
		printf("//( 5 ) Linear16 to Dec\n");
		printf("//( 6 ) Direct to Dec\n");
		printf("//------------------------------------------------//\n\n");

		int select_num = 0;

		printf("[FUNCTION.exe]: select function num:");
		scanf("%d",&select_num);

		if(select_num==1){//function PEC========================================================================================
			char PEC_cmd_str[1000];

			while(1){
				printf("[FUNCTION.exe_PEC]: input I2C cmd:");
				scanf("%s",&PEC_cmd_str);
				if(strncmp("exit", PEC_cmd_str, 4) == 0){
					break;
				}else{
					const char* split_inputcmd = "-";
					char *after_split_inputcmd = strtok(PEC_cmd_str, split_inputcmd);
					int strtok_count_inputcmd = 0;
					printf("\n");

					while (after_split_inputcmd != NULL) {//讀取每一行的切割後						
						UINT8 integer = HexStr_to_int(after_split_inputcmd);	
						CalPec(integer);
						
						printf("string = 0X%s,int = %d\n",after_split_inputcmd,integer);

						after_split_inputcmd = strtok(NULL, split_inputcmd);
						strtok_count_inputcmd++;
					}
					printf("PEC = 0X%X\n\n",ubPmbusPec);
					ubPmbusPec = 0x00;
				}
			}
		}else if(select_num==2){//function DIR_READONLY========================================================================================

			DIR *dir = NULL;
			struct dirent *entry;

			if((dir = opendir(READ_ONLY_Path))==NULL){
				printf("[FUNCTION.exe_DIR_READONLY]: opendir failed!\n");
				system("pause");
			}else{				
				printf("[FUNCTION.exe_DIR_READONLY]: DIR\n");
				while(entry=readdir(dir)) {
					//printf("filename= %s\n",entry->d_name);  //輸出檔案或者目錄的名稱
					//printf("filetype = %d\n",entry->d_type);  //輸出檔案型別
					printf("%s\n",entry->d_name);  //輸出檔案或者目錄的名稱
				}
				closedir(dir);
				system("pause");
			}

		}else if(select_num==3){//function REPORT_DATA_Catch output_list========================================================================================
			char input_case[100];

			while(1){
				printf("[FUNCTION.exe_output_list]:========[Default]=============\n");
				printf("[FUNCTION.exe_output_list]:========[Query]===============\n");
				printf("[FUNCTION.exe_output_list]:========[Time_count]==========\n");
				printf("[FUNCTION.exe_output_list]:========[AutoRecovery]========\n");
				printf("[FUNCTION.exe_output_list]: input report case:");
				scanf("%s",&input_case);
				if(strncmp("exit", input_case, 4) == 0){
					break;
				}else{
					DIR *dir = NULL;
					struct dirent *entry;

					if((dir = opendir(OUTPUT_LIST_Path))==NULL){
						printf("[FUNCTION.exe_output_list]: opendir failed!\n");
					}else{
						while(entry=readdir(dir)) {
							if(entry->d_type == 0){	//文件型別	
								char system_cmd[200];//字串合併
								memset(system_cmd, 0, sizeof(system_cmd));//初始化字串
								strcat(system_cmd, "REPORT_DATA_Catch.exe ");//字串合併
								strcat(system_cmd, input_case);//字串合併
								strcat(system_cmd, " .\\READ_ONLY\\output_list\\");//字串合併
								strcat(system_cmd, entry->d_name);//字串合併
								system(system_cmd);
							}
						}
						closedir(dir);
					}
				}
			}
		}else if(select_num==4){//function Linear11 to Dec========================================================================================
			char Linear11_str[1000];

			while(1){
				printf("[FUNCTION.exe_Linear11]: input Linear11:");
				scanf("%s",&Linear11_str);
				if(strncmp("exit", Linear11_str, 4) == 0){
					break;
				}else{
					printf("\nDec = %s\n\n",Linear11_to_DEC(Linear11_str));
				}
			}
		}else if(select_num==5){//function Linear16 to Dec========================================================================================
			char Linear16_str[1000];

			while(1){
				printf("[FUNCTION.exe_Linear16]: input Linear16:");
				scanf("%s",&Linear16_str);
				if(strncmp("exit", Linear16_str, 4) == 0){
					break;
				}else{
					printf("\nDec = %s\n\n",Linear16_to_DEC(Linear16_str));
				}
			}
		}else if(select_num==6){//function Direct to Dec========================================================================================
			char Direct_str_1[1000];
			char Direct_str_2[1000];

			while(1){
				printf("[FUNCTION.exe_Direct]: input first Direct:");
				scanf("%s",&Direct_str_1);
				if(strncmp("exit", Direct_str_1, 4) == 0){
					break;
				}
				printf("[FUNCTION.exe_Direct]: input second Direct:");
				scanf("%s",&Direct_str_2);
				if(strncmp("exit", Direct_str_2, 4) == 0){
					break;
				}

				char *Direct_to_DEC_return = Direct_to_DEC(Direct_str_1,Direct_str_2);
				printf("\nfirst Direct = %s,\nsecond Direct = %s,\nDec = %s\n\n",Direct_str_1,Direct_str_2,Direct_to_DEC_return);
			}
		}else if(select_num==999){//test========================================================================================
			char test_str[1000];
			int yearmoney;//int yearmoney = 150000;
			int bonusmoney,yearbonus,put_money;
			while(1){
				yearmoney = 0;
				bonusmoney = 0;
				yearbonus = 0;
				put_money = 0;
				printf("[FUNCTION.exe_test]: input:");
				scanf("%s",&test_str);
				if(strncmp("exit", test_str, 4) == 0){
					break;
				}

				yearmoney = HexStr_to_int(test_str);

				for(int year = 1;year<=40;year++){
					// if(year==10){
					// 	yearmoney = 100000;
					// }
					put_money = put_money + yearmoney;
					yearbonus = (put_money + bonusmoney)*0.05;
					bonusmoney = bonusmoney + yearbonus;

					printf("year:%d put %d, bonus %d, totle %d, yearbonus %d\n", 
						year, put_money, bonusmoney, bonusmoney+put_money, yearbonus);
				}
			}
		}else{
			printf("select function not found!\n");
			break;
		}
	}

	return 0;
}