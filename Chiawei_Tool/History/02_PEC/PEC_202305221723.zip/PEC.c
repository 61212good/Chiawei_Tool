#include <stdio.h>
#include <string.h> 
#include <stdlib.h>
typedef volatile unsigned char		UINT8;					// Volatele UINT8
typedef const unsigned char			C_UINT8;				// Constant UINT8
UINT8 ubPmbusPec = 0x00;									// Q0, PMBus PEC
//----- CRC8 -----
C_UINT8 ubaHiCrc[16] = {
	0x00, 0x70, 0xE0, 0x90, 0xC7, 0xB7, 0x27, 0x57,
	0x89, 0xF9, 0x69, 0x19, 0x4E, 0x3E, 0xAE, 0xDE};		// Q0, HiCrc
C_UINT8 ubaLoCrc[16] = {
	0x00, 0x07, 0x0E, 0x09, 0x1C, 0x1B, 0x12, 0x15,
	0x38, 0x3F, 0x36, 0x31, 0x24, 0x23, 0x2A, 0x2D};		// Q0, LoCrc

void CalPec(UINT8 ubData) {
	/********************************************************/
	/*				________								*/
	/*				|		|								*/
	/*	ubData	--->|		|--->	ubPmbusPec				*/
	/*				|_______|								*/
	/*														*/
	/*	Description:										*/
	/*	Calculation PEC (CRC-8) for communication			*/
	/*														*/
	/********************************************************/
//-- C
	UINT8 iubHiByte;										// Q0, High byte
	UINT8 iubLoByte;										// Q0, Low byte

	ubPmbusPec ^= ubData;									// Q0, ubPmbusPec
	iubHiByte = (ubPmbusPec >> 4) & 0x0F;					// Q0, iubHiByte
	iubLoByte = ubPmbusPec & 0x0F;							// Q0, iubLoByte
	ubPmbusPec = ubaHiCrc[iubHiByte];						// Q0, ubPmbusPec
	ubPmbusPec ^= ubaLoCrc[iubLoByte];						// Q0, ubPmbusPec
}

int main(int argc, char *argv[]){
	/*char* input_val;
	char strcat_dest[1000];//字串合併
	for(int i=0;i<argc;i++){
		if(i!=0){
			input_val = argv[i];

			memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串
			strcat(strcat_dest, "0X");//字串合併
			strcat(strcat_dest, input_val);//字串合併
    		
    		UINT8 integer = strtoul(strcat_dest, NULL, 0);
			CalPec(integer);
			
			printf("string = %s,int = %d\n",strcat_dest,integer);
		}
	}
	printf("PEC = 0X%X\n",ubPmbusPec);*/
	
	char input_cmd_str[100];
	char input_cmd[10];
	while(1){

		printf("input:");
		scanf("%s",input_cmd_str);
		const char* split_inputcmd = "-";
		char *after_split_inputcmd = strtok(input_cmd_str, split_inputcmd);
		int strtok_count_inputcmd = 0;

		while (after_split_inputcmd != NULL) {//讀取每一行的切割後
			memset(input_cmd, 0, sizeof(input_cmd));//初始化字串
			strcat(input_cmd, "0X");//字串合併
			strcat(input_cmd, after_split_inputcmd);//字串合併
    		
    		UINT8 integer = strtoul(input_cmd, NULL, 0);
			CalPec(integer);
			
			printf("string = %s,int = %d\n",input_cmd,integer);

			after_split_inputcmd = strtok(NULL, split_inputcmd);
			strtok_count_inputcmd++;
		}
		printf("PEC = 0X%X\n\n",ubPmbusPec);
		ubPmbusPec = 0x00;

	}
	return 0;
}