//----------------------------------------------------[C]--------------------------------------------------------------//
gcc REPOERT_DATA_Catch.c & a.exe Default .\READ_ONLY\test_defaultlog.txt
gcc REPOERT_DATA_Catch.c & a.exe Query .\READ_ONLY\test_querylog.txt

REPOERT_DATA_Catch.exe Default .\READ_ONLY\test_defaultlog.txt
REPOERT_DATA_Catch.exe Query .\READ_ONLY\test_querylog.txt