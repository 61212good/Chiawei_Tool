#include <stdio.h>
#include <stdlib.h>
#include "dirent.h"

#define FilePath "./READ_ONLY/"
	
int main(){
	DIR *dir = NULL;
	struct dirent *entry;

	if((dir = opendir(FilePath))==NULL){
		printf("opendir failed!");
		return -1;
	}else{
		while(entry=readdir(dir)) {
			//printf("filename= %s\n",entry->d_name);  //輸出檔案或者目錄的名稱
			//printf("filetype = %d\n",entry->d_type);  //輸出檔案型別
			printf("%s\n",entry->d_name);  //輸出檔案或者目錄的名稱
		}
		closedir(dir);
	}
	//system("D:\\1_Chiawei_tool\\CHICONY_POWER\\a.exe");
	system("pause");

	return 0;
}