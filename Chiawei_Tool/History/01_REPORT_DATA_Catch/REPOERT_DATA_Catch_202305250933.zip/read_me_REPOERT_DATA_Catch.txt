//----------------------------------------------------[C]--------------------------------------------------------------//
gcc REPOERT_DATA_Catch.c & a.exe Default .\READ_ONLY\testlog_default.txt
gcc REPOERT_DATA_Catch.c & a.exe Query .\READ_ONLY\testlog_query.txt
gcc REPOERT_DATA_Catch.c & a.exe Time_count .\READ_ONLY\testbootloader_Timecount.txt
gcc REPOERT_DATA_Catch.c & a.exe AutoRecovery .\READ_ONLY\testlog_autorecovery.txt
gcc REPOERT_DATA_Catch.c & a.exe function_HextoDec Linear11
gcc REPOERT_DATA_Catch.c & a.exe function_HextoDec Linear16
gcc REPOERT_DATA_Catch.c & a.exe function_HextoDec Direct
gcc REPOERT_DATA_Catch.c & a.exe test test


REPOERT_DATA_Catch.exe Default .\READ_ONLY\testlog_default.txt
REPOERT_DATA_Catch.exe Query .\READ_ONLY\testlog_query.txt
REPOERT_DATA_Catch.exe Time_count .\READ_ONLY\testbootloader_Timecount.txt
REPOERT_DATA_Catch.exe AutoRecovery .\READ_ONLY\testlog_autorecovery.txt
REPOERT_DATA_Catch.exe function_HextoDec Linear11
REPOERT_DATA_Catch.exe function_HextoDec Linear16
REPOERT_DATA_Catch.exe function_HextoDec Direct
//----------------------------------------------------[function]--------------------------------------------------------------//
/* substr [提取 `src` 中存在的字符]
* @param {char*} src 原始的文字
* @param {int} m 開始的位置
* @param {int} n n-1=結束位置
* */ 
/* str_replace [字串取代] 
* @param {char*} source 原始的文字 
* @param {char*} find 搜尋的文字   
* @param {char*} rep 替換的文字 
* */ 
/* Hexstr_to_int [HexStr to int] 
* @param {char*} hex_val 要轉換的HexData
* */ 
/* Linear16_to_DEC [Linear16 to DEC] 
* @param {char*} hex_val 要轉換的HexData
* */ 
/* Linear11_to_DEC [Linear11 to DEC] 
* @param {char*} hex_val 要轉換的HexData
* */
/* Direct_to_DEC [Direct to DEC] 
* @param {char*} read_data_last I2C讀到的Data(上一筆資料)(不含開頭0x06)
* @param {char*} read_data_current I2C讀到的Data(新的一筆資料)(不含開頭0x06)
* */