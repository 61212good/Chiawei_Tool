1.安裝CURL後需新增到環境變數，
例:"C:\curl-8.7.1_7-win64-mingw\bin"