//----------------------------------------------------[C]--------------------------------------------------------------//
gcc FUNCTION.c & a.exe

FUNCTION.exe
//----------------------------------------------------[1_PEC]--------------------------------------------------------------//
[FUNCTION.exe_PEC]: input I2C cmd:B0-00-00

string = 0XB0,int = 176
string = 0X00,int = 0
string = 0X00,int = 0
PEC = 0XEA
//----------------------------------------------------[2_DIR_READ_ONLY]---------------------------------------------------------//
[FUNCTION.exe_DIR_READONLY]: DIR
.
..
testbootloader_Timecount.txt
testlog_autorecovery.txt
testlog_default.txt
testlog_query.txt
請按任意鍵繼續 . . .
//----------------------------------------------------[3_REPORT_DATA_Catch output_list]-----------------------------------------//
[FUNCTION.exe_output_list]:========[Default]=============
[FUNCTION.exe_output_list]:========[Query]===============
[FUNCTION.exe_output_list]:========[Time_count]==========
[FUNCTION.exe_output_list]:========[AutoRecovery]========
[FUNCTION.exe_output_list]: input report case:Query
.\OUTPUT\output_list\testlog_query_1_Query_ReadValue.txt
.\OUTPUT\output_list\testlog_query_2_Query_ReadValue.txt
.\OUTPUT\output_list\testlog_query_3_Query_ReadValue.txt