#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#define Nlen 10000//讀檔案每一行最大容量
#define maxlen 241//每一行最大的資料數量
#define total_catchlen ((241*3)-1)+3//擷取的字元總數(包含Register+:)
/* substr [提取 `src` 中存在的字符]
* @param {char*} src 原始的文字
* @param {int} m 開始的位置
* @param {int} n n-1=結束位置
* */ 
char* substr(const char *src, int m, int n)
{
	// 獲取目標字符串的長度
	int len = n - m;
 
	// 為目標分配 (len + 1) 個字符(+1 用於額外的空字符)
	char *dest = (char*)malloc(sizeof(char) * (len + 1));
 
	// 從源字符串中提取第 m 個和第 n 個索引之間的字符
	// 並將它們複製到目標字符串中
	for (int i = m; i < n && (*(src + i) != '\0'); i++)
	{
		*dest = *(src + i);
		dest++;
	}
 
	// 以空值結束目標字符串
	*dest = '\0';
 
	// 返回目標字符串
	return dest - len;
}
/* str_replace [字串取代] 
* @param {char*} source 原始的文字 
* @param {char*} find 搜尋的文字   
* @param {char*} rep 替換的文字 
* */ 
char *str_replace (char *source, char *find,  char *rep){ 
	// 搜尋文字的長度 
	int find_L=strlen(find); 
	// 替換文字的長度 
	int rep_L=strlen(rep); 
	// 結果文字的長度 
	int length=strlen(source)+1; 
	// 定位偏移量 
	int gap=0; 
 
	// 建立結果文字，並複製文字 
	char *result = (char*)malloc(sizeof(char) * length); 
	strcpy(result, source);	 
 
	// 尚未被取代的字串 
	char *former=source; 
	// 搜尋文字出現的起始位址指標 
	char *location= strstr(former, find); 
 
	// 漸進搜尋欲替換的文字 
	while(location!=NULL){ 
		// 增加定位偏移量 
		gap+=(location - former); 
		// 將結束符號定在搜尋到的位址上 
		result[gap]='\0'; 
 
		// 計算新的長度 
		length+=(rep_L-find_L); 
		// 變更記憶體空間 
		result = (char*)realloc(result, length * sizeof(char)); 
		// 替換的文字串接在結果後面 
		strcat(result, rep); 
		// 更新定位偏移量 
		gap+=rep_L; 
 
		// 更新尚未被取代的字串的位址 
		former=location+find_L; 
		// 將尚未被取代的文字串接在結果後面 
		strcat(result, former); 
 
		// 搜尋文字出現的起始位址指標 
		location= strstr(former, find); 
	}
	return result; 
}

int main(int argc, char *argv[]){
	//printf("argc_enter: %d\n",argc);//參數數量
	char* input_case;
	for(int i=0;i<argc;i++){
		//printf("argv_%d_enter: %s\n",i,argv[i]);//參數字串
		if(i==1){//模式參數
			input_case = argv[1];//輸入參數
		}else if(i==2){//文件地址參數
			char* input_filename = argv[2];//輸入字串
			char* output_filename_Default_ReadValue_0 = str_replace(input_filename,".txt","_Default_ReadValue.txt");//輸出Default_ReadValue檔名
			char* output_filename_Default_ReadValue = str_replace(output_filename_Default_ReadValue_0,"READ_ONLY","OUTPUT");//輸出Default_ReadValue檔名
			char* output_filename_Default_7Eh_0 = str_replace(input_filename,".txt","_Default_7Eh.txt");//輸出Default_7Eh檔名
			char* output_filename_Default_7Eh = str_replace(output_filename_Default_7Eh_0,"READ_ONLY","OUTPUT");//輸出Default_7Eh檔名
			char* output_filename_Query_ReadValue_0 = str_replace(input_filename,".txt","_Query_ReadValue.txt");//輸出Query_ReadValue檔名
			char* output_filename_Query_ReadValue = str_replace(output_filename_Query_ReadValue_0,"READ_ONLY","OUTPUT");//輸出Query_ReadValue檔名

			FILE *fptr_read = fopen(input_filename,"r");

			if(strncmp("Default", input_case, 7) == 0){//判斷輸入參數Default=========================================================
				if(fptr_read == NULL){//判斷文件是否打開失敗
					puts("Fail to open file!");
					exit(0);
				}else{
					char readstr[Nlen + 1];
					int fgets_count = 0;
					FILE *fptr_write_default_readvalue = fopen(output_filename_Default_ReadValue,"w");
					FILE *fptr_write_default_7eh = fopen(output_filename_Default_7Eh,"w");
					while(fgets(readstr, Nlen, fptr_read) != NULL){//讀取每一行
						if(fgets_count!=0){//第一行不讀
							if((fgets_count%3)==1){//第一行Default_log--------------------------------------------------------------
								const char* split = "：";
								char *after_split = strtok(readstr, split);
								int strtok_count = 0;
								while (after_split != NULL) {//讀取每一行的切割後
									if(strtok_count==1){//讀取切割後第二個字串
										char* after_replace_0 = str_replace(after_split," S 58 W ","");//取代
										char* after_replace_1 = str_replace(after_replace_0," Sr 58  R ",":");//取代
										char* after_replace = str_replace(after_replace_1," ","-");//取代

										char* Deafault_rowdata = substr(after_replace,3,total_catchlen);//after_substr一行的DEFAULT資料
										char* Deafault_rowdata_tmp = substr(after_replace,3,total_catchlen);//after_substr一行的DEFAULT資料

										const char* Deafault_row_split = "-";
										char *after_Deafault_row_split = strtok(Deafault_rowdata, Deafault_row_split);
										int Deafault_row_split_count = 0;
										char *last_data = "";
										int nowdata_address = 0;
										int savedata_count = 0;

										while (after_Deafault_row_split != NULL) {//讀取一行的DEFAULT資料切割後
											if(strncmp("FF", after_Deafault_row_split, 2) == 0 && 
												nowdata_address != 0 && 
												strncmp("FF", last_data, 2) != 0){//當前資料為FF，且不是第一個資料，且上一個資料不是FF
												savedata_count = nowdata_address - 1;//擷取的資料數量
											}
											last_data = after_Deafault_row_split;
											nowdata_address++;

											after_Deafault_row_split = strtok(NULL, Deafault_row_split);
											Deafault_row_split_count++;
										}

										if(savedata_count == 0 || strncmp("FF", last_data, 2) != 0){//若全為FF或最後一個資料不是FF
											savedata_count = maxlen;//擷取的資料數量
										}

										int savedata_address = (savedata_count * 3) - 1;//擷取的字元總數

										Deafault_rowdata = substr(Deafault_rowdata_tmp,0,savedata_address);//after_substr一行的DEFAULT資料

										char strcat_dest[1000];//字串合併
										memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串
										strcat(strcat_dest, Deafault_rowdata);//字串合併
										strcat(strcat_dest, "h\n");//字串合併

										fprintf(fptr_write_default_readvalue,"%s",strcat_dest);
									}
									after_split = strtok(NULL, split);
									strtok_count++;
								}
							}else if((fgets_count%3)==2){//第二行7Eh_log--------------------------------------------------------------
								const char* split = "：";
								char *after_split = strtok(readstr, split);
								int strtok_count = 0;
								while (after_split != NULL) {//讀取每一行的切割後
									if(strtok_count==1){//讀取切割後第二個字串
										char* after_replace_0 = str_replace(after_split," S 58 W 06 02 00 7E Sr 58  R 01 ","");//取代
										char* after_replace_1 = str_replace(after_replace_0," S 58 W 06 02 01 7E Sr 58  R 01 ","");//取代

										char* after_substr = substr(after_replace_1,0,3);//after_substr

										char* after_replace = str_replace(after_substr," ","h\n");//取代

										fprintf(fptr_write_default_7eh,"%s",after_replace);
									}
									after_split = strtok(NULL, split);
									strtok_count++;
								}
							}else if((fgets_count%3)==3){//第三行clearfault
								
							}
						}
						fgets_count++;
					}
					fclose(fptr_write_default_readvalue);
					fclose(fptr_write_default_7eh);

					printf("%s\n", output_filename_Default_ReadValue);
					printf("%s\n", output_filename_Default_7Eh);
				}

				fclose(fptr_read);
			}else if(strncmp("Query", input_case, 5) == 0){//判斷輸入參數Query=========================================================
				if(fptr_read == NULL){//判斷文件是否打開失敗
					puts("Fail to open file!");
					exit(0);
				}else{
					char readstr[Nlen + 1];
					int fgets_count = 0;
					FILE *fptr_write_query_readvalue = fopen(output_filename_Query_ReadValue,"w");
					while(fgets(readstr, Nlen, fptr_read) != NULL){//讀取每一行
						const char* split = "：";
						char *after_split = strtok(readstr, split);
						int strtok_count = 0;
						while (after_split != NULL) {//讀取每一行的切割後
							if(strtok_count==1){//讀取切割後第二個字串
								char strcat_dest[1000];//字串合併
								memset(strcat_dest, 0, sizeof(strcat_dest));//初始化字串

								char* after_replace_0 = str_replace(after_split," S 58 W 1A 01 ","");//取代
								char* after_replace_1 = str_replace(after_replace_0," Sr 58  R ",":");//取代
								char* after_replace_2 = str_replace(after_replace_1," ","-");//取代

								char* after_substr = substr(after_replace_2,3,8);//after_substr

								strcat(strcat_dest, after_substr);//字串合併
								strcat(strcat_dest, "h\n");//字串合併

								fprintf(fptr_write_query_readvalue,"%s",strcat_dest);
							}
							after_split = strtok(NULL, split);
							strtok_count++;
						}
						fgets_count++;
					}
					fclose(fptr_write_query_readvalue);

					printf("%s\n", output_filename_Query_ReadValue);
				}

				fclose(fptr_read);
			}else{
				puts("Fail to switch_case!");
				exit(0);
			}
		}
	}
	return 0;
}