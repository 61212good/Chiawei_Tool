//----------------------------------------------------[C]--------------------------------------------------------------//
gcc REPOERT_DATA_Catch.c & a.exe Default .\READ_ONLY\testlog_default.txt
gcc REPOERT_DATA_Catch.c & a.exe Query .\READ_ONLY\testlog_query.txt
gcc REPOERT_DATA_Catch.c & a.exe Time_count .\READ_ONLY\testTime_count.txt

REPOERT_DATA_Catch.exe Default .\READ_ONLY\testlog_default.txt
REPOERT_DATA_Catch.exe Query .\READ_ONLY\testlog_query.txt
REPOERT_DATA_Catch.exe Time_count .\READ_ONLY\testTime_count.txt