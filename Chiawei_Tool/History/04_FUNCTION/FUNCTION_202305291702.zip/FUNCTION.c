#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "dirent.h"

#define READ_ONLY_Path "./READ_ONLY/"						//READ_ONLY PATH
#define OUTPUT_LIST_Path "./READ_ONLY/output_list/"						//READ_ONLY PATH

typedef volatile unsigned char		UINT8;					// Volatele UINT8
typedef const unsigned char			C_UINT8;				// Constant UINT8
UINT8 ubPmbusPec = 0x00;									// Q0, PMBus PEC

//----- CRC8 -----
C_UINT8 ubaHiCrc[16] = {
	0x00, 0x70, 0xE0, 0x90, 0xC7, 0xB7, 0x27, 0x57,
	0x89, 0xF9, 0x69, 0x19, 0x4E, 0x3E, 0xAE, 0xDE};		// Q0, HiCrc
C_UINT8 ubaLoCrc[16] = {
	0x00, 0x07, 0x0E, 0x09, 0x1C, 0x1B, 0x12, 0x15,
	0x38, 0x3F, 0x36, 0x31, 0x24, 0x23, 0x2A, 0x2D};		// Q0, LoCrc

/* CalPec [計算PEC] 
* @param {UINT8} ubData 要計算PEC的Hex
* */ 
void CalPec(UINT8 ubData) {
	/********************************************************/
	/*				________								*/
	/*				|		|								*/
	/*	ubData	--->|		|--->	ubPmbusPec				*/
	/*				|_______|								*/
	/*														*/
	/*	Description:										*/
	/*	Calculation PEC (CRC-8) for communication			*/
	/*														*/
	/********************************************************/
//-- C
	UINT8 iubHiByte;										// Q0, High byte
	UINT8 iubLoByte;										// Q0, Low byte

	ubPmbusPec ^= ubData;									// Q0, ubPmbusPec
	iubHiByte = (ubPmbusPec >> 4) & 0x0F;					// Q0, iubHiByte
	iubLoByte = ubPmbusPec & 0x0F;							// Q0, iubLoByte
	ubPmbusPec = ubaHiCrc[iubHiByte];						// Q0, ubPmbusPec
	ubPmbusPec ^= ubaLoCrc[iubLoByte];						// Q0, ubPmbusPec
}
/* Hexstr_to_int [HexStr to int] 
* @param {char*} hex_val 要轉換的HexData
* */ 
int HexStr_to_int(char *hex_val){
	int result = 0;
	char HexStr[100];//字串合併
	memset(HexStr, 0, sizeof(HexStr));//初始化字串
	strcat(HexStr, "0X");//字串合併
	strcat(HexStr, hex_val);//字串合併
	result = strtoul(HexStr, NULL, 0);

	return result;
}

int main(){
	while(1){
		printf("//------------------------------------------------//\n");
		printf("//function List:\n");
		printf("//( 1 ) PEC\n");
		printf("//( 2 ) DIR_READONLY\n");
		printf("//( 3 ) REPORT_DATA_Catch output_list\n");
		printf("//------------------------------------------------//\n\n");

		int select_num = 0;

		printf("[FUNCTION.exe]: select function num:");
		scanf("%d",&select_num);

		if(select_num==1){//function PEC========================================================================================
			char PEC_cmd_str[100];

			while(1){
				printf("[FUNCTION.exe_PEC]: input I2C cmd:");
				scanf("%s",&PEC_cmd_str);
				if(strncmp("exit", PEC_cmd_str, 4) == 0){
					break;
				}else{
					const char* split_inputcmd = "-";
					char *after_split_inputcmd = strtok(PEC_cmd_str, split_inputcmd);
					int strtok_count_inputcmd = 0;
					printf("\n");

					while (after_split_inputcmd != NULL) {//讀取每一行的切割後						
						UINT8 integer = HexStr_to_int(after_split_inputcmd);
						CalPec(integer);
						
						printf("string = 0X%s,int = %d\n",after_split_inputcmd,integer);

						after_split_inputcmd = strtok(NULL, split_inputcmd);
						strtok_count_inputcmd++;
					}
					printf("PEC = 0X%X\n\n",ubPmbusPec);
					ubPmbusPec = 0x00;
				}
			}
		}else if(select_num==2){//function DIR_READONLY========================================================================================

			DIR *dir = NULL;
			struct dirent *entry;

			if((dir = opendir(READ_ONLY_Path))==NULL){
				printf("[FUNCTION.exe_DIR_READONLY]: opendir failed!\n");
				system("pause");
			}else{				
				printf("[FUNCTION.exe_DIR_READONLY]: DIR\n");
				while(entry=readdir(dir)) {
					//printf("filename= %s\n",entry->d_name);  //輸出檔案或者目錄的名稱
					//printf("filetype = %d\n",entry->d_type);  //輸出檔案型別
					printf("%s\n",entry->d_name);  //輸出檔案或者目錄的名稱
				}
				closedir(dir);
				system("pause");
			}

		}else if(select_num==3){//function REPORT_DATA_Catch output_list========================================================================================
			char input_case[100];

			while(1){
				printf("[FUNCTION.exe_output_list]:========[Default]=============\n");
				printf("[FUNCTION.exe_output_list]:========[Query]===============\n");
				printf("[FUNCTION.exe_output_list]:========[Time_count]==========\n");
				printf("[FUNCTION.exe_output_list]:========[AutoRecovery]========\n");
				printf("[FUNCTION.exe_output_list]: input report case:");
				scanf("%s",&input_case);
				if(strncmp("exit", input_case, 4) == 0){
					break;
				}else{
					DIR *dir = NULL;
					struct dirent *entry;

					if((dir = opendir(OUTPUT_LIST_Path))==NULL){
						printf("[FUNCTION.exe_output_list]: opendir failed!\n");
					}else{
						while(entry=readdir(dir)) {
							if(entry->d_type == 0){	//文件型別	
								char system_cmd[200];//字串合併
								memset(system_cmd, 0, sizeof(system_cmd));//初始化字串
								strcat(system_cmd, "REPORT_DATA_Catch.exe ");//字串合併
								strcat(system_cmd, input_case);//字串合併
								strcat(system_cmd, " .\\READ_ONLY\\output_list\\");//字串合併
								strcat(system_cmd, entry->d_name);//字串合併
								system(system_cmd);
							}
						}
						closedir(dir);
					}
				}
			}
		}else{
			printf("select function not found!\n");
			break;
		}
	}

	return 0;
}