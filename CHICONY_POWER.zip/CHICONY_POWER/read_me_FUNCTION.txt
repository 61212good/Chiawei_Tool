//----------------------------------------------------[C]--------------------------------------------------------------//
gcc FUNCTION.c & a.exe

FUNCTION.exe
//----------------------------------------------------[1_PEC]--------------------------------------------------------------//
[FUNCTION.exe_PEC]: input I2C cmd:B0-00-00

string = 0XB0,int = 176
string = 0X00,int = 0
string = 0X00,int = 0
PEC = 0XEA
//----------------------------------------------------[2_DIR_READ_ONLY]---------------------------------------------------------//
[FUNCTION.exe_DIR_READONLY]: DIR
.
..
testbootloader_Timecount.txt
testlog_autorecovery.txt
testlog_default.txt
testlog_query.txt
請按任意鍵繼續 . . .
//----------------------------------------------------[3_REPORT_DATA_Catch output_list]-----------------------------------------//
[FUNCTION.exe_output_list]:========[Default]=============
[FUNCTION.exe_output_list]:========[Query]===============
[FUNCTION.exe_output_list]:========[Time_count]==========
[FUNCTION.exe_output_list]:========[AutoRecovery]========
[FUNCTION.exe_output_list]: input report case:Query
.\OUTPUT\output_list\testlog_query_1_Query_ReadValue.txt
.\OUTPUT\output_list\testlog_query_2_Query_ReadValue.txt
.\OUTPUT\output_list\testlog_query_3_Query_ReadValue.txt
//----------------------------------------------------[4_Linear11_to_DEC]------------------------------------------------------//
[FUNCTION.exe_Linear11]: input Linear11:F076

Dec = 29.500000
//----------------------------------------------------[5_Linear16_to_DEC]------------------------------------------------------//
[FUNCTION.exe_Linear16]: input Linear16:1B00

Dec = 13.500000
//----------------------------------------------------[6_Direct_to_DEC]--------------------------------------------------------//
[FUNCTION.exe_Direct]: input first Direct:53-65-0B-4E-0C-00
[FUNCTION.exe_Direct]: input second Direct:1F-39-0C-FB-0C-00

first Direct = 53-65-0B-4E-0C-00,
second Direct = 1F-39-0C-FB-0C-00,
Dec = 123.000000
//----------------------------------------------------[function]---------------------------------------------------------------//
/* CalPec [計算PEC] 
* @param {UINT8} ubData 要計算PEC的Hex
* */
/* Hexstr_to_int [HexStr to int] 
* @param {char*} hex_val 要轉換的HexData
* */ 
/* Linear16_to_DEC [Linear16 to DEC] 
* @param {char*} hex_val 要轉換的HexData
* */ 
/* Linear11_to_DEC [Linear11 to DEC] 
* @param {char*} hex_val 要轉換的HexData
* */
/* Direct_to_DEC [Direct to DEC] 
* @param {char*} read_data_last I2C讀到的Data(上一筆資料)(不含開頭0x06)
* @param {char*} read_data_current I2C讀到的Data(新的一筆資料)(不含開頭0x06)
* */